"use strict";
(() => {
  // dist/assets/normalize-control-bar-section-visibility-CgaI_d6p.js
  var p = { availableThemesAriaLabel: "Available themes", buttonGuideSubtitle: "Left click and right click can perform different actions.", buttonGuideTitle: "Button guide", captionsButtonLabel: "CC", captionsDisableAriaLabel: "Disable captions", captionsDisableTitle: "Disable captions (Z)", captionsEnableAriaLabel: "Enable captions", captionsEnableTitle: "Enable captions (Z)", captionsUnavailableTitle: "Captions are not available for this video", controlBarSectionCaptions: "Captions", controlBarSectionMusic: "Music mode", controlBarSectionPin: "Pin controls", controlBarSectionQuality: "Quality controls", controlBarSectionSpeed: "Speed controls", controlBarSectionTime: "Time controls", controlBarSectionVolume: "Volume controls", controlBarSectionsAriaLabel: "Visible control bar sections", controlBarSectionsSubtitle: "Choose which groups appear on the player bar.", controlBarSectionsTitle: "Visible sections", extActionTitle: "Playback Controls for YouTube\u2122", extDescription: "Adds quick playback speed, seek, quality, captions, and style controls to the YouTube player.", extName: "Playback Controls For YouTube\u2122", guideCaptionsLeftClick: "Toggles captions on or off when available.", guideCaptionsRightClick: "No secondary action.", guideCategoryCaptions: "Captions", guideCategoryCurrentSpeed: "Current speed", guideCategoryCurrentVolume: "Current volume", guideCategoryMusic: "Music mode", guideCategoryResolution: "Resolution", guideCategorySpeed: "Speed", guideCategoryTime: "Time", guideCategoryVolume: "Volume", guideCurrentSpeedLeftClick: "Resets speed to 1.00x.", guideCurrentSpeedRightClick: "No secondary action.", guideCurrentVolumeLeftClick: "Resets volume to 100%.", guideCurrentVolumeRightClick: "No secondary action.", guideMusicLeftClick: "Toggles music mode. Blacks out the video and selects the lowest resolution to save data and lighten system load.", guideMusicRightClick: "No secondary action.", guideResolutionLeftClick: "Chooses Auto or the closest resolution.", guideResolutionRightClick: "Changes the resolution button target.", guideSpeedLeftClick: "Changes speed by 0.05x.", guideSpeedRightClick: "Changes speed by 0.10x.", guideTimeLeftClick: "Skips backward or forward by the indicated amount.", guideTimeRightClick: "Fast forwards at 4x until reaching the point.", guideVolumeLeftClick: "Changes volume by 10%. Can boost above 100%, up to 200%.", guideVolumeRightClick: "Changes volume by 20%.", leftClickLabel: "Left click", musicModeDisableAriaLabel: "Disable music mode", musicModeDisableTitle: "Disable music mode", musicModeEnableAriaLabel: "Enable music mode", musicModeEnableTitle: "Enable music mode", pinDisableAriaLabel: "Unpin player controls", pinDisableTitle: "Unpin player controls", pinEnableAriaLabel: "Pin player controls", pinEnableTitle: "Pin player controls", popupAppearanceToggleToDarkAriaLabel: "Switch popup to dark mode", popupAppearanceToggleToLightAriaLabel: "Switch popup to light mode", popupDocumentTitle: "Playback Controls for YouTube\u2122", popupHeaderSubtitle: "Choose the theme for your YouTube controls.", popupHeaderTitle: "Control bar style", previewAriaLabel: "Control bar preview", qualityAutoLabel: "Auto", qualityAutoTitle: "Select YouTube Auto quality", qualityResolutionTitle: "Select $RESOLUTION$p or the closest available resolution", rateResetAriaLabel: "Reset playback speed to 1.00x", rateResetTitle: "Reset playback speed to 1.00x", resetButton: "Reset", resetSectionsButton: "Reset sections", rightClickLabel: "Right click", seekForward15Label: "15s\u2192", seekForward15Title: "Forward 15 seconds", seekForward30Label: "30s\u2192", seekForward30Title: "Forward 30 seconds", seekForward60Label: "60s\u2192", seekForward60Title: "Forward 60 seconds", seekRewind15Label: "\u219015s", seekRewind15Title: "Rewind 15 seconds", seekRewind30Label: "\u219030s", seekRewind30Title: "Rewind 30 seconds", seekRewind60Label: "\u219060s", seekRewind60Title: "Rewind 60 seconds", speedDecreaseLabel: "-5% | -10%", speedDecreaseTitle: "Click: decrease 0.05x. Right click: decrease 0.10x", speedIncreaseLabel: "+5% | +10%", speedIncreaseTitle: "Click: increase 0.05x. Right click: increase 0.10x", themeClassicDescription: "Light gray bar with white buttons, matching the original style.", themeClassicName: "Classic", themeDarkDescription: "A low-light friendly bar for watching videos at night.", themeDarkName: "Dark", themeOceanDescription: "Soft blues with clear readability over video.", themeOceanName: "Ocean", themeRoseDescription: "Warm, compact, and softly accented.", themeRoseName: "Rose", themeYoutubeDescription: "Red, white, and black with a familiar platform accent.", themeYoutubeName: "YouTube", themesSubtitle: "Choose the player bar colors.", themesTitle: "Themes", volumeDecreaseLabel: "\u{1F509} -10%", volumeDecreaseTitle: "Click: decrease volume by 10%. Right click: decrease volume by 20%", volumeIncreaseLabel: "\u{1F50A} +10%", volumeIncreaseTitle: "Click: increase volume by 10%. Right click: increase volume by 20%" };
  var b = { availableThemesAriaLabel: [], buttonGuideSubtitle: [], buttonGuideTitle: [], captionsButtonLabel: [], captionsDisableAriaLabel: [], captionsDisableTitle: [], captionsEnableAriaLabel: [], captionsEnableTitle: [], captionsUnavailableTitle: [], controlBarSectionCaptions: [], controlBarSectionMusic: [], controlBarSectionPin: [], controlBarSectionQuality: [], controlBarSectionSpeed: [], controlBarSectionTime: [], controlBarSectionVolume: [], controlBarSectionsAriaLabel: [], controlBarSectionsSubtitle: [], controlBarSectionsTitle: [], extActionTitle: [], extDescription: [], extName: [], guideCaptionsLeftClick: [], guideCaptionsRightClick: [], guideCategoryCaptions: [], guideCategoryCurrentSpeed: [], guideCategoryCurrentVolume: [], guideCategoryMusic: [], guideCategoryResolution: [], guideCategorySpeed: [], guideCategoryTime: [], guideCategoryVolume: [], guideCurrentSpeedLeftClick: [], guideCurrentSpeedRightClick: [], guideCurrentVolumeLeftClick: [], guideCurrentVolumeRightClick: [], guideMusicLeftClick: [], guideMusicRightClick: [], guideResolutionLeftClick: [], guideResolutionRightClick: [], guideSpeedLeftClick: [], guideSpeedRightClick: [], guideTimeLeftClick: [], guideTimeRightClick: [], guideVolumeLeftClick: [], guideVolumeRightClick: [], leftClickLabel: [], musicModeDisableAriaLabel: [], musicModeDisableTitle: [], musicModeEnableAriaLabel: [], musicModeEnableTitle: [], pinDisableAriaLabel: [], pinDisableTitle: [], pinEnableAriaLabel: [], pinEnableTitle: [], popupAppearanceToggleToDarkAriaLabel: [], popupAppearanceToggleToLightAriaLabel: [], popupDocumentTitle: [], popupHeaderSubtitle: [], popupHeaderTitle: [], previewAriaLabel: [], qualityAutoLabel: [], qualityAutoTitle: [], qualityResolutionTitle: ["resolution"], rateResetAriaLabel: [], rateResetTitle: [], resetButton: [], resetSectionsButton: [], rightClickLabel: [], seekForward15Label: [], seekForward15Title: [], seekForward30Label: [], seekForward30Title: [], seekForward60Label: [], seekForward60Title: [], seekRewind15Label: [], seekRewind15Title: [], seekRewind30Label: [], seekRewind30Title: [], seekRewind60Label: [], seekRewind60Title: [], speedDecreaseLabel: [], speedDecreaseTitle: [], speedIncreaseLabel: [], speedIncreaseTitle: [], themeClassicDescription: [], themeClassicName: [], themeDarkDescription: [], themeDarkName: [], themeOceanDescription: [], themeOceanName: [], themeRoseDescription: [], themeRoseName: [], themeYoutubeDescription: [], themeYoutubeName: [], themesSubtitle: [], themesTitle: [], volumeDecreaseLabel: [], volumeDecreaseTitle: [], volumeIncreaseLabel: [], volumeIncreaseTitle: [] };
  function m(e) {
    return e.replaceAll(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function k(e, t) {
    const i = p[e];
    if (typeof i != "string" || i.length === 0) return null;
    const o = t?.map((l) => String(l)) ?? [], u = b[e] ?? [];
    let a = i;
    return u.forEach((l, s) => {
      const d = o[s] ?? "";
      a = a.replaceAll(new RegExp(`\\$${m(l)}\\$`, "gi"), d);
    }), o.forEach((l, s) => {
      a = a.replaceAll(`$${s + 1}`, l);
    }), a;
  }
  var g = 0;
  var n = 2;
  var T = 1;
  function C(e) {
    const t = Number.isFinite(e) ? e : n / 2;
    return Math.min(n, Math.max(g, t));
  }
  var c = ["time", "speed", "volume", "quality", "music", "captions", "pin"];
  var L = "playbackControlsForYoutubeVisibleSections";
  var r = Object.freeze({ time: true, speed: true, volume: true, quality: true, music: true, captions: true, pin: true });
  function R(e, t = false) {
    if (t) return "0%";
    const i = C(e);
    return `${Math.round(i * 100)}%`;
  }
  function h(e) {
    return c.some((t) => e[t]);
  }
  function y(e) {
    if (!e || typeof e != "object" || Array.isArray(e)) return r;
    const t = e, i = Object.fromEntries(c.map((o) => [o, typeof t[o] == "boolean" ? t[o] : r[o]]));
    return h(i) ? i : r;
  }

  // dist/assets/index.iife.ts-orLqaBSp.js
  function c2(e, i) {
    try {
      const s = chrome.i18n?.getMessage?.(e, i) ?? "";
      if (s) return s;
    } catch {
    }
    return k(e, i) ?? e;
  }
  function wo(e) {
    return e.AudioContext ?? e.webkitAudioContext ?? null;
  }
  function Ao(e) {
    if (e.audioContext) return e.audioContext;
    const i = wo(e.window);
    return i ? (e.audioContext = new i(), e.audioContext) : null;
  }
  function Lo(e, i) {
    const s = Ao(e);
    if (!s) return null;
    try {
      const o = s.createMediaElementSource(i), r2 = s.createGain();
      return o.connect(r2), r2.connect(s.destination), { gain: r2, source: o };
    } catch {
      return null;
    }
  }
  function No(e, i) {
    const s = e.chains.get(i);
    if (s) return s;
    const o = Lo(e, i);
    return o && e.chains.set(i, o), o;
  }
  function Nt(e) {
    e.activeChain && (e.activeChain.gain.gain.value = 1), e.activeChain = null;
  }
  function Po(e) {
    e.warnedUnavailable || (e.warnedUnavailable = true, e.logger.warn?.());
  }
  function _o(e, i, s) {
    if (s <= 1) return Nt(e), true;
    const o = No(e, i);
    return o ? (e.activeChain && e.activeChain !== o && (e.activeChain.gain.gain.value = 1), o.gain.gain.value = s, e.activeChain = o, true) : (Po(e), Nt(e), false);
  }
  function Ro(e, i) {
    return { activeChain: null, audioContext: null, chains: /* @__PURE__ */ new WeakMap(), logger: i, warnedUnavailable: false, window: e };
  }
  async function Io(e) {
    try {
      e.audioContext?.state === "suspended" && await e.audioContext.resume();
    } catch {
      e.logger.warn?.();
    }
  }
  var Bo = ["More videos", "M\xE1s videos", "Plus de vid\xE9os", "Weitere Videos", "Altri video", "Mais v\xEDdeos", "\u66F4\u591A\u89C6\u9891", "\u66F4\u591A\u5F71\u7247", "\u305D\u306E\u4ED6\u306E\u52D5\u753B", "\uB2E4\uB978 \uB3D9\uC601\uC0C1", "\u0627\u0644\u0645\u0632\u064A\u062F \u0645\u0646 \u0627\u0644\u0641\u064A\u062F\u064A\u0648\u0647\u0627\u062A", "Meer video's", "Wi\u0119cej film\xF3w", "\u0414\u0440\u0443\u0433\u0438\u0435 \u0432\u0438\u0434\u0435\u043E", "Di\u011Fer videolar", "Th\xEAm video", "\u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E40\u0E15\u0E34\u0E21"];
  function Mo(e, i) {
    const s = Number.isFinite(e) ? e + i : 1 + i;
    return C(Math.round(s * 10) / 10);
  }
  var te = "__youtube_playback_speed_controls__";
  var ht = "data-playback-controls-for-youtube-host";
  var gn = "playback-controls-for-youtube-tm-global-style";
  var N = "yt-playback-speed-controls-pinned";
  var ee = "yt-playback-speed-controls-music-mode";
  var Oo = 0.25;
  var Vo = 4;
  var ne = 0.05;
  var hn = 0.1;
  var kn = 0.1;
  var En = 0.2;
  var Sn = 15;
  var xn = 30;
  var Tn = 60;
  var Cn = 4;
  var we = 100;
  var Do = 8;
  var Yo = 5e3;
  var qo = 250;
  var Fo = 250;
  var wn = 750;
  var Uo = 144;
  var $o = [1080];
  var Ae = [240, 360, 480, 720, 1080];
  var An = 68;
  var Ln = 42;
  var Q = "youtubePlaybackPositions";
  var Ko = 1e4;
  var ie = 1;
  var jo = 5;
  var zo = 200;
  var Go = 350;
  var Qo = 12e3;
  var Ho = 3500;
  var At = 0.75;
  var Wo = 3;
  var Xo = 500;
  var Jo = 40;
  var Zo = 1500;
  var tr = 6e4;
  var er = 300;
  var Le = "playbackControlsForYoutubeTheme";
  var st = "classic";
  var Ne = { classic: { id: "classic", tokens: { barBackground: "rgba(204, 204, 204, 0.96)", barBorder: "rgba(0, 0, 0, 0.22)", barShadow: "0 2px 10px rgba(0, 0, 0, 0.28)", buttonBackground: "#ffffff", buttonText: "#111111", buttonBorder: "rgba(0, 0, 0, 0.16)", buttonHoverBackground: "#f1f1f1", activeBackground: "#e6f3ff", activeBorder: "#3ea6ff", activeText: "#065fd4", activeShadow: "0 0 0 1px rgba(255, 255, 255, 0.35), 0 0 12px rgba(62, 166, 255, 0.55)", focusRing: "#3ea6ff", dividerColor: "rgba(0, 0, 0, 0.45)", borderRadius: "999px" } }, dark: { id: "dark", tokens: { barBackground: "rgba(22, 24, 28, 0.94)", barBorder: "rgba(255, 255, 255, 0.16)", barShadow: "0 8px 22px rgba(0, 0, 0, 0.46)", buttonBackground: "#2c3038", buttonText: "#f7f7f7", buttonBorder: "rgba(255, 255, 255, 0.14)", buttonHoverBackground: "#3a404b", activeBackground: "#263f5f", activeBorder: "#7ab7ff", activeText: "#eaf4ff", activeShadow: "0 0 0 1px rgba(122, 183, 255, 0.32), 0 0 14px rgba(122, 183, 255, 0.38)", focusRing: "#7ab7ff", dividerColor: "rgba(255, 255, 255, 0.38)", borderRadius: "999px" } }, youtube: { id: "youtube", tokens: { barBackground: "rgba(20, 20, 20, 0.94)", barBorder: "rgba(255, 255, 255, 0.14)", barShadow: "0 6px 18px rgba(0, 0, 0, 0.4)", buttonBackground: "#ffffff", buttonText: "#0f0f0f", buttonBorder: "rgba(255, 255, 255, 0.18)", buttonHoverBackground: "#ffe7e7", activeBackground: "#ff0033", activeBorder: "#ff5c75", activeText: "#ffffff", activeShadow: "0 0 0 1px rgba(255, 255, 255, 0.3), 0 0 14px rgba(255, 0, 51, 0.46)", focusRing: "#ff5c75", dividerColor: "rgba(255, 255, 255, 0.42)", borderRadius: "999px" } }, ocean: { id: "ocean", tokens: { barBackground: "rgba(219, 245, 255, 0.95)", barBorder: "rgba(14, 116, 144, 0.28)", barShadow: "0 5px 18px rgba(8, 47, 73, 0.24)", buttonBackground: "#f8fdff", buttonText: "#0f2e3d", buttonBorder: "rgba(14, 116, 144, 0.2)", buttonHoverBackground: "#d9f4ff", activeBackground: "#0e7490", activeBorder: "#22d3ee", activeText: "#ffffff", activeShadow: "0 0 0 1px rgba(255, 255, 255, 0.34), 0 0 13px rgba(34, 211, 238, 0.44)", focusRing: "#0891b2", dividerColor: "rgba(15, 46, 61, 0.42)", borderRadius: "14px" } }, rose: { id: "rose", tokens: { barBackground: "rgba(255, 232, 236, 0.96)", barBorder: "rgba(190, 24, 93, 0.22)", barShadow: "0 5px 18px rgba(131, 24, 67, 0.22)", buttonBackground: "#ffffff", buttonText: "#4a102b", buttonBorder: "rgba(190, 24, 93, 0.18)", buttonHoverBackground: "#ffe0ea", activeBackground: "#be185d", activeBorder: "#fb7185", activeText: "#ffffff", activeShadow: "0 0 0 1px rgba(255, 255, 255, 0.36), 0 0 13px rgba(251, 113, 133, 0.42)", focusRing: "#e11d48", dividerColor: "rgba(74, 16, 43, 0.4)", borderRadius: "10px" } } };
  var nr = { auto: Number.NaN, default: Number.NaN, highres: 4320, hd4320: 4320, hd2880: 2880, hd2160: 2160, hd1440: 1440, hd1080: 1080, hd720: 720, large: 480, medium: 360, small: 240, tiny: 144 };
  function or(e) {
    return typeof e == "string" && e in Ne ? Ne[e] : Ne[st];
  }
  function rr(e) {
    return { "--yt-controls-bar-background": e.tokens.barBackground, "--yt-controls-bar-border": e.tokens.barBorder, "--yt-controls-bar-shadow": e.tokens.barShadow, "--yt-controls-button-background": e.tokens.buttonBackground, "--yt-controls-button-text": e.tokens.buttonText, "--yt-controls-button-border": e.tokens.buttonBorder, "--yt-controls-button-hover-background": e.tokens.buttonHoverBackground, "--yt-controls-active-background": e.tokens.activeBackground, "--yt-controls-active-border": e.tokens.activeBorder, "--yt-controls-active-text": e.tokens.activeText, "--yt-controls-active-shadow": e.tokens.activeShadow, "--yt-controls-focus-ring": e.tokens.focusRing, "--yt-controls-divider-color": e.tokens.dividerColor, "--yt-controls-border-radius": e.tokens.borderRadius };
  }
  function ar(e) {
    return e.document ?? globalThis.document;
  }
  function ir(e) {
    return e.window ?? globalThis.window;
  }
  function Bn(e) {
    return Number.isFinite(e) ? Math.min(Vo, Math.max(Oo, Math.round(e * 100) / 100)) : 1;
  }
  function Nn(e) {
    return `${Bn(e ?? 1).toFixed(2)}x`;
  }
  function kt(e) {
    return e.replace(/\s+/g, " ").trim().toLowerCase();
  }
  function Mn(e) {
    return kt(e).startsWith("auto");
  }
  function sr(e) {
    const i = kt(e);
    if (!i) return null;
    const s = nr[i];
    if (typeof s == "number" && !Number.isNaN(s)) return s;
    const o = i.match(/(\d{3,4})\s*p\b/) ?? i.match(/hd(\d{3,4})\b/) ?? i.match(/(\d{3,4})/);
    if (!o) return null;
    const r2 = Number(o[1]);
    return Number.isFinite(r2) ? r2 : null;
  }
  function On(e) {
    const i = e.find((s) => Mn(s.label));
    return i ? { label: i.label, resolution: null, element: i.element } : null;
  }
  function lr(e, i) {
    let s = null, o = Number.POSITIVE_INFINITY;
    for (const r2 of i) {
      if (r2.resolution === null) continue;
      const u = Math.abs(r2.resolution - e);
      (!s || u < o || u === o && r2.resolution < (s.resolution ?? Number.POSITIVE_INFINITY)) && (s = { label: r2.label, resolution: r2.resolution, element: r2.element }, o = u);
    }
    return s || On(i);
  }
  function ur(e, i) {
    return Bn(e + i);
  }
  function _e(e) {
    return typeof e == "string" && /^[A-Za-z0-9_-]{6,128}$/.test(e);
  }
  function Ie(e) {
    try {
      const i = new URL(e, "https://www.youtube.com"), s = i.searchParams.get("v");
      if (_e(s)) return s;
      const [o, r2] = i.pathname.split("/").filter(Boolean);
      if ((o === "shorts" || o === "embed" || o === "live") && _e(r2)) return r2;
    } catch {
      return null;
    }
    return null;
  }
  function Vn(e) {
    try {
      return new URL(e, "https://www.youtube.com").pathname.split("/").filter(Boolean)[0] === "watch" && Ie(e) !== null;
    } catch {
      return false;
    }
  }
  function Be(e) {
    return !(!e || e.id !== "movie_player" && !e.closest("#movie_player") || e.closest("ytd-thumbnail, ytd-playlist-thumbnail, #thumbnail"));
  }
  function cr(e) {
    if (typeof e != "string") return null;
    const i = e.trim().toLowerCase();
    if (!i) return null;
    if (/^\d+(?:\.\d+)?s?$/.test(i)) {
      const m2 = Number(i.replace(/s$/, ""));
      return Number.isFinite(m2) && m2 >= 0 ? Math.floor(m2) : null;
    }
    const s = i.match(/^(?:(\d+(?:\.\d+)?)h)?(?:(\d+(?:\.\d+)?)m)?(?:(\d+(?:\.\d+)?)s)?$/);
    if (!s || !s[1] && !s[2] && !s[3]) return null;
    const o = s[1] ? Number(s[1]) : 0, r2 = s[2] ? Number(s[2]) : 0, u = s[3] ? Number(s[3]) : 0, v = o * 3600 + r2 * 60 + u;
    return Number.isFinite(v) && v >= 0 ? Math.floor(v) : null;
  }
  function dr(e) {
    try {
      const i = new URL(e, "https://www.youtube.com");
      return cr(i.searchParams.get("t"));
    } catch {
      return null;
    }
  }
  function ae(e, i, s) {
    const o = Math.max(0, Math.floor(Number.isFinite(s) ? s : 0)), r2 = new URL(e, "https://www.youtube.com");
    return r2.pathname = "/watch", r2.searchParams.set("v", i), r2.searchParams.set("t", `${o}s`), r2.hash = "", `${r2.pathname}${r2.search}${r2.hash}`;
  }
  function U(e) {
    const i = e.defaultView?.location.href;
    if (!i || !Vn(i)) return null;
    const s = Array.from(e.querySelectorAll("video"));
    return pr(e, s);
  }
  function re(e, i) {
    const s = e.defaultView?.location.href;
    if (!s || !Vn(s)) return null;
    if (i) {
      const o = i.closest("#movie_player, .html5-video-player");
      if (o && Be(o)) return o.id === "movie_player" ? o : o.closest("#movie_player") ?? o;
    }
    return fr(e, Array.from(e.querySelectorAll("#movie_player, .html5-video-player")));
  }
  function br(e, i) {
    const s = re(e, i);
    if (s) {
      const o = s?.querySelector(".ytp-chrome-bottom");
      if (o) return o;
    }
    return e.querySelector("#movie_player .ytp-chrome-bottom, .html5-video-player .ytp-chrome-bottom");
  }
  function Re(e, i) {
    if (!i || !i.isConnected) return Number.NEGATIVE_INFINITY;
    let s = 0;
    const r2 = e.defaultView?.getComputedStyle(i);
    (r2?.display === "none" || r2?.visibility === "hidden" || r2?.opacity === "0") && (s -= 1e4);
    const u = i.getBoundingClientRect();
    return u.width > 0 && u.height > 0 && (s += 1e3 + Math.min(u.width * u.height, 1e6) / 1e3), s;
  }
  function Dn(e) {
    if (!e) return 0;
    let i = 0;
    return e.id === "movie_player" && (i += 100), e.classList.contains("html5-video-player") && (i += 50), i;
  }
  function pr(e, i) {
    let s = null, o = Number.NEGATIVE_INFINITY;
    for (const r2 of i) {
      const u = r2.closest("#movie_player, .html5-video-player");
      if (!Be(u)) continue;
      const v = Re(e, r2) + (u ? Re(e, u) : 0) + Dn(u);
      (!s || v > o) && (s = r2, o = v);
    }
    return s;
  }
  function fr(e, i) {
    let s = null, o = Number.NEGATIVE_INFINITY;
    for (const r2 of i) {
      if (!Be(r2)) continue;
      const u = Re(e, r2) + Dn(r2);
      (!s || u > o) && (s = r2, o = u);
    }
    return s;
  }
  function mr(e) {
    const i = e.querySelectorAll(".ytp-menuitem");
    return i.length > 0 ? i[i.length - 1] : null;
  }
  function yr(e) {
    return Array.from(e.querySelectorAll(".ytp-menuitem")).map((i) => {
      const s = kt(i.textContent ?? "");
      if (!s) return null;
      const o = sr(s);
      return o === null && !Mn(s) ? null : { label: s, resolution: o, element: i };
    }).filter((i) => i !== null);
  }
  function oe(e) {
    return e?.querySelector(".ytp-subtitles-button") ?? null;
  }
  function Pn(e) {
    return e?.querySelector(".ytp-caption-window-container") ?? null;
  }
  function _n(e, i, s, o) {
    const r2 = i.querySelector(s);
    return r2 ? Promise.resolve(r2) : new Promise((u) => {
      const v = i instanceof Document ? i.documentElement : i, m2 = new MutationObserver(() => {
        const y2 = i.querySelector(s);
        y2 && (f(), u(y2));
      }), V = e.setTimeout(() => {
        f(), u(null);
      }, o), f = () => {
        m2.disconnect(), e.clearTimeout(V);
      };
      m2.observe(v, { childList: true, subtree: true });
    });
  }
  function vr(e) {
    try {
      const i = e.localStorage, s = (o) => {
        const r2 = i.getItem(Q);
        if (o === Q) return r2 ? JSON.parse(r2) : void 0;
      };
      return { get(o, r2) {
        try {
          if (typeof o == "string") {
            r2({ [o]: s(o) });
            return;
          }
          if (Array.isArray(o)) {
            r2(Object.fromEntries(o.map((u) => [u, s(u)])));
            return;
          }
          if (o && typeof o == "object") {
            r2(Object.fromEntries(Object.entries(o).map(([u, v]) => [u, s(u) ?? v])));
            return;
          }
          r2({ [Q]: s(Q) });
        } catch {
          r2({});
        }
      }, set(o, r2) {
        try {
          for (const [u, v] of Object.entries(o)) typeof v > "u" ? i.removeItem(u) : u === Q && i.setItem(u, JSON.stringify(v));
        } catch {
        }
        r2?.();
      } };
    } catch {
      return null;
    }
  }
  function gr(e, i) {
    return "storage" in e ? e.storage ?? null : vr(i);
  }
  function hr(e) {
    if (!e || typeof e != "object" || Array.isArray(e)) return {};
    const i = {};
    for (const [s, o] of Object.entries(e)) {
      if (!_e(s) || !o || typeof o != "object" || Array.isArray(o)) continue;
      const r2 = o, u = Number(r2.time);
      if (!Number.isFinite(u) || u < ie) continue;
      const v = Number(r2.duration), m2 = Number(r2.updatedAt), V = typeof r2.url == "string" ? r2.url : "", f = V && Ie(V) === s ? ae(V, s, u) : ae(`https://www.youtube.com/watch?v=${s}`, s, u);
      i[s] = { url: f, time: u, duration: Number.isFinite(v) && v > 0 ? v : null, updatedAt: Number.isFinite(m2) ? m2 : 0 };
    }
    return i;
  }
  function kr(e) {
    const i = Object.entries(e).sort(([, s], [, o]) => o.updatedAt - s.updatedAt);
    return Object.fromEntries(i.slice(0, zo));
  }
  function Rn(e, i) {
    return e ? new Promise((s) => {
      try {
        e.get(Q, (o) => {
          s(hr(o?.[Q]));
        });
      } catch (o) {
        i.warn?.(o instanceof Error ? o.message : "Could not read the saved video position."), s({});
      }
    }) : Promise.resolve({});
  }
  function Er(e, i, s) {
    if (e) try {
      e.set({ [Q]: kr(i) });
    } catch (o) {
      s.warn?.(o instanceof Error ? o.message : "Could not save the video position.");
    }
  }
  function lt(e) {
    return Number.isFinite(e.duration) && e.duration > 0 ? e.duration : null;
  }
  function Me(e, i) {
    return i !== null && e >= Math.max(ie, i - jo);
  }
  function Sr(e) {
    const i = e.currentTime;
    return Number.isFinite(i) && i >= ie && !Me(i, lt(e));
  }
  function xr(e) {
    const i = e.currentTime;
    return e.ended || Number.isFinite(i) && Me(i, lt(e));
  }
  function Pe(e, i) {
    return e.time >= ie && !Me(e.time, lt(i) ?? e.duration);
  }
  function In(e) {
    return Math.max(0, e.time - Wo);
  }
  function Tr(e) {
    if (!(e instanceof Element)) return false;
    const i = e.tagName.toLowerCase();
    return i === "input" || i === "textarea" || i === "select" || e.closest('[contenteditable="true"], [role="textbox"]') !== null;
  }
  async function Cr(e, i) {
    const s = i.querySelector(".ytp-quality-menu");
    if (s) return s;
    const o = i.querySelector(".ytp-settings-button");
    if (!o) return null;
    o.click();
    const r2 = await _n(e, i, ".ytp-settings-menu", wn);
    if (!r2) return null;
    const u = mr(r2);
    return u ? (u.click(), _n(e, i, ".ytp-quality-menu", wn)) : null;
  }
  function wr(e = {}) {
    const i = ar(e), s = ir(e);
    if (!i || !s) return { destroy() {
    } };
    const o = i, r2 = s, u = r2, v = u[te];
    if (v && typeof v == "object" && "destroy" in v) return v;
    let m2 = false, V = false, f = { video: null, controlsRoot: null, playerContainer: null }, y2 = null, se = null, le = false, ut = null, _ = 0, R2 = null, Oe = null, g2 = null, H = null, Pt = null, I = null, Ve = 0, h2 = null, D = null, ue = null, _t = null, ce = 0, de = Ae.length - 1, ct = false, $ = null, dt = null, K = false, W = null, k2 = null, Rt = null, It = null, De = 0, Bt = null, be = r;
    const x = e.logger ?? console, Et = Ro(r2, x);
    let B = null, Ye = 0;
    const St = gr(e, r2), S = o.createElement("div");
    S.setAttribute(ht, "1");
    function qe() {
      const t = { position: "absolute", left: "0", right: "0", top: "auto", bottom: `${An}px`, "z-index": "2147483647", width: "100%", height: `${Ln}px`, "box-sizing": "border-box", display: "flex", "align-items": "center", "justify-content": "center", overflow: "visible" };
      for (const [n2, a] of Object.entries(t)) S.style.setProperty(n2, a, "important");
    }
    qe();
    function Yn(t) {
      const n2 = r2.getComputedStyle(t).position;
      (!n2 || n2 === "static") && t.style.setProperty("position", "relative", "important");
    }
    const qn = Bo.flatMap((t) => {
      const n2 = t.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
      return [`.html5-video-player.ytp-fullscreen .ytp-button[aria-label="${n2}"]`, `.html5-video-player.ytp-fullscreen .ytp-button[title="${n2}"]`];
    }).join(`,
    `), Mt = o.createElement("style");
    Mt.id = gn, Mt.textContent = `
    .html5-video-player.ytp-fullscreen .ytp-fullscreen-grid-expand-button,
    ${qn} {
      display: none !important;
    }

    .html5-video-player.${N} .ytp-chrome-bottom,
    .html5-video-player.${N} .ytp-chrome-top,
    .html5-video-player.${N} .ytp-chrome-controls,
    .html5-video-player.${N} .ytp-gradient-bottom,
    .html5-video-player.${N} .ytp-gradient-top,
    .html5-video-player.${N} .ytp-progress-bar-container {
      opacity: 1 !important;
      visibility: visible !important;
      pointer-events: auto !important;
      transform: none !important;
    }

    .html5-video-player.${N} .ytp-chrome-bottom {
      bottom: 0 !important;
    }

    .html5-video-player [${ht}] {
      opacity: 1 !important;
      visibility: visible !important;
      pointer-events: auto !important;
      transition: opacity 160ms ease, visibility 160ms ease;
    }

    .html5-video-player.ytp-autohide:not(.${N}) [${ht}] {
      opacity: 0 !important;
      visibility: hidden !important;
      pointer-events: none !important;
    }

    .html5-video-player.${N} [${ht}] {
      opacity: 1 !important;
      visibility: visible !important;
      pointer-events: auto !important;
    }

    .html5-video-player.yt-playback-speed-fast-seek-captions .ytp-caption-window-container {
      opacity: 0 !important;
      visibility: hidden !important;
    }

    .html5-video-player.${ee} video {
      opacity: 0 !important;
      visibility: hidden !important;
    }

    .yt-playback-speed-music-overlay {
      position: absolute;
      inset: 0;
      z-index: 1;
      display: block;
      background-color: #050505;
      background-position: center;
      background-repeat: no-repeat;
      background-size: contain;
      pointer-events: none;
    }

    .yt-playback-speed-music-overlay::after {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(to bottom, rgba(0, 0, 0, 0.08), rgba(0, 0, 0, 0.34));
    }

    .yt-playback-speed-fast-seek-caption-overlay {
      position: absolute;
      left: 50%;
      bottom: 58px;
      z-index: 9998;
      display: none;
      flex-direction: column;
      align-items: center;
      gap: 3px;
      width: min(86%, 960px);
      transform: translateX(-50%);
      pointer-events: none;
      color: #fff;
      font-family: Roboto, Arial, sans-serif;
      font-size: clamp(18px, 2.3vw, 32px);
      font-weight: 500;
      line-height: 1.28;
      text-align: center;
      text-shadow: 0 0 2px #000, 0 0 4px #000;
    }

    .yt-playback-speed-fast-seek-caption-overlay[data-visible="true"] {
      display: flex;
    }

    .yt-playback-speed-fast-seek-caption-line {
      width: max-content;
      max-width: 100%;
      box-sizing: border-box;
      padding: 2px 6px;
      border-radius: 2px;
      background: rgba(8, 8, 8, 0.82);
      white-space: normal;
      overflow-wrap: anywhere;
    }
  `, o.getElementById(gn)?.remove(), (o.head ?? o.documentElement).append(Mt);
    const Fn = S.attachShadow({ mode: "open" }), Fe = o.createElement("style");
    Fe.textContent = `
    :host {
      all: initial;
      display: flex;
      align-items: center;
      justify-content: center;
      box-sizing: border-box;
      position: absolute;
      left: 0;
      bottom: ${An}px;
      z-index: 9999;
      width: 100%;
      height: ${Ln}px;
      box-sizing: border-box;
      padding: 0 8px;
      overflow: visible;
      pointer-events: auto;
    }

    .yt-speed-root {
      display: flex;
      align-items: center;
      align-self: center;
      gap: 8px;
      max-width: 100%;
      margin: 0;
      padding: 4px 6px;
      border: 1px solid var(--yt-controls-bar-border);
      border-radius: var(--yt-controls-border-radius);
      background: var(--yt-controls-bar-background);
      box-shadow: var(--yt-controls-bar-shadow);
      line-height: 1;
      font-family: Roboto, Arial, sans-serif;
      overflow-x: auto;
      overflow-y: hidden;
      scrollbar-width: none;
      pointer-events: auto;
    }

    .yt-speed-root::-webkit-scrollbar {
      display: none;
    }

    .yt-seek-group,
    .yt-speed-group,
    .yt-volume-group,
    .yt-quality-group,
    .yt-music-group,
    .yt-captions-group,
    .yt-pin-group {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      min-width: 0;
    }

    .yt-seek-group {
      justify-content: center;
    }

    .yt-seek-group .yt-speed-button[aria-pressed="true"] {
      transform: translateY(1px);
      outline: 2px solid var(--yt-controls-focus-ring);
      outline-offset: 1px;
      box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.32);
    }

    .yt-speed-button {
      appearance: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border: 1px solid var(--yt-controls-button-border);
      border-radius: var(--yt-controls-border-radius);
      min-width: 42px;
      height: 28px;
      padding: 0 10px;
      background: var(--yt-controls-button-background);
      color: var(--yt-controls-button-text);
      font-size: 12px;
      font-weight: 700;
      line-height: 1;
      cursor: pointer;
      transition: transform 120ms ease, background-color 120ms ease, border-color 120ms ease;
      user-select: none;
    }

    .yt-seek-button-15 {
      background: var(--yt-controls-button-background);
    }

    .yt-seek-button-rewind-30 {
      background: #ffb3b3;
      border-color: #ff8585;
      color: #111111;
    }

    .yt-seek-button-rewind-60 {
      background: #ff7777;
      border-color: #f05252;
      color: #111111;
    }

    .yt-seek-button-forward-30 {
      background: #b9f6c7;
      border-color: #82e69a;
      color: #111111;
    }

    .yt-seek-button-forward-60 {
      background: #72d987;
      border-color: #43bd5c;
      color: #111111;
    }

    .yt-speed-rate {
      appearance: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 52px;
      height: 28px;
      padding: 0 10px;
      border: 1px solid var(--yt-controls-button-border);
      border-radius: var(--yt-controls-border-radius);
      background: var(--yt-controls-button-background);
      color: var(--yt-controls-button-text);
      font-size: 12px;
      font-weight: 700;
      line-height: 1;
      font-variant-numeric: tabular-nums;
      letter-spacing: 0.02em;
      cursor: pointer;
      transition: transform 120ms ease, background-color 120ms ease, border-color 120ms ease;
      user-select: none;
    }

    .yt-speed-rate[aria-pressed="true"] {
      transform: translateY(1px);
      outline: 2px solid var(--yt-controls-focus-ring);
      outline-offset: 1px;
      background: var(--yt-controls-active-background);
      border-color: var(--yt-controls-active-border);
      color: var(--yt-controls-active-text);
      box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.24);
    }

    [data-role="volume-indicator"] {
      align-items: center;
      justify-content: center;
      min-width: 64px;
      width: 64px;
      height: 28px;
      padding: 0 8px;
      font-size: 12px;
      line-height: 1;
      text-align: center;
      letter-spacing: 0.02em;
    }

    [data-role="volume-indicator"][data-volume-boost-level="1"] {
      background: #ffe8ef;
      border-color: #fac8d6;
      color: #5f1630;
    }

    [data-role="volume-indicator"][data-volume-boost-level="2"] {
      background: #ffe1ea;
      border-color: #f6b5c8;
      color: #5f1630;
    }

    [data-role="volume-indicator"][data-volume-boost-level="3"] {
      background: #ffd9e3;
      border-color: #f2a9bd;
      color: #5f1630;
    }

    [data-role="volume-indicator"][data-volume-boost-level="4"] {
      background: #ffd1dc;
      border-color: #ee9db2;
      color: #5f1630;
    }

    [data-role="volume-indicator"][data-volume-boost-level="5"] {
      background: #ffc8d4;
      border-color: #ea91a7;
      color: #5f1630;
    }

    [data-role="volume-indicator"][data-volume-boost-level="6"] {
      background: #ffbecb;
      border-color: #e6849c;
      color: #5f1630;
    }

    [data-role="volume-indicator"][data-volume-boost-level="7"] {
      background: #ffb4c2;
      border-color: #e27791;
      color: #5f1630;
    }

    [data-role="volume-indicator"][data-volume-boost-level="8"] {
      background: #ffa9b8;
      border-color: #de6a86;
      color: #5f1630;
    }

    [data-role="volume-indicator"][data-volume-boost-level="9"] {
      background: #ff9dad;
      border-color: #da5d7b;
      color: #5f1630;
    }

    [data-role="volume-indicator"][data-volume-boost-level="10"] {
      background: #ff90a1;
      border-color: #d65070;
      color: #5f1630;
    }

    .yt-volume-group .yt-speed-button {
      min-width: 64px;
      width: 64px;
      padding: 0 8px;
    }

    .yt-volume-group .yt-speed-rate {
      cursor: pointer;
      pointer-events: auto;
    }

    .yt-speed-divider {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      color: var(--yt-controls-divider-color);
      font-size: 14px;
      font-weight: 400;
      line-height: 1;
      padding: 0 2px;
      user-select: none;
      pointer-events: none;
      align-self: center;
    }

    .yt-quality-button,
    .yt-captions-button {
      appearance: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border: 1px solid var(--yt-controls-button-border);
      border-radius: var(--yt-controls-border-radius);
      min-width: 46px;
      height: 28px;
      padding: 0 8px;
      background: var(--yt-controls-button-background);
      color: var(--yt-controls-button-text);
      font-size: 11px;
      font-weight: 700;
      line-height: 1;
      cursor: pointer;
      transition: transform 120ms ease, background-color 120ms ease, border-color 120ms ease;
      user-select: none;
    }

    .yt-quality-button[aria-pressed="true"],
    .yt-captions-button[aria-pressed="true"] {
      background: var(--yt-controls-active-background);
      border-color: var(--yt-controls-active-border);
      color: var(--yt-controls-active-text);
      box-shadow: var(--yt-controls-active-shadow);
    }

    .yt-captions-button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      transform: none;
    }

    .yt-music-button,
    .yt-pin-button {
      appearance: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 30px;
      min-width: 30px;
      height: 28px;
      padding: 0;
      border: 1px solid var(--yt-controls-button-border);
      border-radius: var(--yt-controls-border-radius);
      background: var(--yt-controls-button-background);
      color: var(--yt-controls-button-text);
      cursor: pointer;
      transition: transform 120ms ease, background-color 120ms ease, border-color 120ms ease, color 120ms ease;
      user-select: none;
    }

    .yt-music-button svg,
    .yt-pin-button svg {
      width: 15px;
      height: 15px;
      display: block;
      pointer-events: none;
    }

    .yt-music-button[aria-pressed="true"],
    .yt-pin-button[aria-pressed="true"] {
      background: var(--yt-controls-active-background);
      border-color: var(--yt-controls-active-border);
      color: var(--yt-controls-active-text);
      box-shadow: var(--yt-controls-active-shadow);
    }

    .yt-speed-button:hover {
      background: var(--yt-controls-button-hover-background);
      border-color: var(--yt-controls-active-border);
      transform: translateY(-1px);
    }

    .yt-seek-button-15:hover {
      background: var(--yt-controls-button-hover-background);
    }

    .yt-seek-button-rewind-30:hover {
      background: #ffa0a0;
      border-color: #ff7474;
    }

    .yt-seek-button-rewind-60:hover {
      background: #ff6767;
      border-color: #e84747;
    }

    .yt-seek-button-forward-30:hover {
      background: #a7f0b8;
      border-color: #70da89;
    }

    .yt-seek-button-forward-60:hover {
      background: #62ce78;
      border-color: #39ad52;
    }

    .yt-speed-rate:hover {
      background: var(--yt-controls-button-hover-background);
      border-color: var(--yt-controls-active-border);
      transform: translateY(-1px);
    }

    .yt-quality-button:hover,
    .yt-captions-button:hover:not(:disabled) {
      background: var(--yt-controls-button-hover-background);
      border-color: var(--yt-controls-active-border);
      transform: translateY(-1px);
    }

    .yt-quality-button[aria-pressed="true"]:hover,
    .yt-captions-button[aria-pressed="true"]:hover {
      background: var(--yt-controls-active-background);
      border-color: var(--yt-controls-active-border);
    }

    .yt-music-button:hover,
    .yt-pin-button:hover {
      background: var(--yt-controls-button-hover-background);
      border-color: var(--yt-controls-active-border);
      transform: translateY(-1px);
    }

    .yt-music-button[aria-pressed="true"]:hover,
    .yt-pin-button[aria-pressed="true"]:hover {
      background: var(--yt-controls-active-background);
      border-color: var(--yt-controls-active-border);
    }

    .yt-speed-button:active {
      transform: translateY(0);
    }

    .yt-speed-rate:active {
      transform: translateY(0);
    }

    .yt-quality-button:active,
    .yt-captions-button:active {
      transform: translateY(0);
    }

    .yt-music-button:active,
    .yt-pin-button:active {
      transform: translateY(0);
    }

    .yt-speed-button:focus-visible {
      outline: 2px solid var(--yt-controls-focus-ring);
      outline-offset: 2px;
    }

    .yt-speed-rate:focus-visible {
      outline: 2px solid var(--yt-controls-focus-ring);
      outline-offset: 2px;
    }

    .yt-quality-button:focus-visible,
    .yt-captions-button:focus-visible {
      outline: 2px solid var(--yt-controls-focus-ring);
      outline-offset: 2px;
    }

    .yt-music-button:focus-visible,
    .yt-pin-button:focus-visible {
      outline: 2px solid var(--yt-controls-focus-ring);
      outline-offset: 2px;
    }
  `;
    const xt = o.createElement("div");
    xt.className = "yt-speed-root";
    function pe(t) {
      const n2 = or(t);
      xt.dataset.theme = n2.id;
      for (const [a, l] of Object.entries(rr(n2))) xt.style.setProperty(a, l);
    }
    function Ue() {
      return globalThis.chrome?.storage?.local ?? null;
    }
    function Un() {
      const t = Ue();
      return t ? new Promise((n2) => {
        try {
          t.get({ [Le]: st }, (a) => {
            try {
              n2(a?.[Le] ?? st);
            } catch {
              n2(st);
            }
          });
        } catch {
          n2(st);
        }
      }) : Promise.resolve(st);
    }
    function $e(t, n2) {
      if (n2 !== "local") return;
      const a = t[Le];
      a && pe(a.newValue);
    }
    function $n() {
      try {
        globalThis.chrome?.storage?.onChanged?.addListener($e);
      } catch {
      }
    }
    function Kn() {
      try {
        globalThis.chrome?.storage?.onChanged?.removeListener($e);
      } catch {
      }
    }
    function jn() {
      const t = Ue();
      return t ? new Promise((n2) => {
        try {
          t.get({ [L]: r }, (a) => {
            n2(a?.[L] ?? r);
          });
        } catch {
          n2(r);
        }
      }) : Promise.resolve(r);
    }
    pe(st), $n(), Un().then((t) => {
      m2 || pe(t);
    });
    const Ot = o.createElement("div");
    Ot.className = "yt-seek-group", Ot.dataset.role = "seek-group";
    const Vt = o.createElement("div");
    Vt.className = "yt-speed-group", Vt.dataset.role = "speed-group";
    const bt = o.createElement("button");
    bt.type = "button", bt.className = "yt-speed-button", bt.textContent = c2("speedDecreaseLabel"), bt.title = c2("speedDecreaseTitle");
    const X = o.createElement("button");
    X.type = "button", X.className = "yt-speed-button yt-seek-button-15", X.setAttribute("aria-pressed", "false"), X.textContent = c2("seekRewind15Label"), X.title = c2("seekRewind15Title");
    const J = o.createElement("button");
    J.type = "button", J.className = "yt-speed-button yt-seek-button-rewind-30", J.setAttribute("aria-pressed", "false"), J.textContent = c2("seekRewind30Label"), J.title = c2("seekRewind30Title");
    const Z = o.createElement("button");
    Z.type = "button", Z.className = "yt-speed-button yt-seek-button-rewind-60", Z.setAttribute("aria-pressed", "false"), Z.textContent = c2("seekRewind60Label"), Z.title = c2("seekRewind60Title");
    const pt = o.createElement("button");
    pt.type = "button", pt.className = "yt-speed-button", pt.textContent = c2("speedIncreaseLabel"), pt.title = c2("speedIncreaseTitle");
    const tt = o.createElement("button");
    tt.type = "button", tt.className = "yt-speed-button yt-seek-button-15", tt.setAttribute("aria-pressed", "false"), tt.textContent = c2("seekForward15Label"), tt.title = c2("seekForward15Title");
    const et = o.createElement("button");
    et.type = "button", et.className = "yt-speed-button yt-seek-button-forward-30", et.setAttribute("aria-pressed", "false"), et.textContent = c2("seekForward30Label"), et.title = c2("seekForward30Title");
    const nt = o.createElement("button");
    nt.type = "button", nt.className = "yt-speed-button yt-seek-button-forward-60", nt.setAttribute("aria-pressed", "false"), nt.textContent = c2("seekForward60Label"), nt.title = c2("seekForward60Title");
    const E = o.createElement("button");
    E.type = "button", E.className = "yt-speed-rate", E.dataset.role = "rate-indicator", E.setAttribute("aria-live", "polite"), E.setAttribute("aria-atomic", "true"), E.setAttribute("aria-pressed", "false"), E.setAttribute("aria-label", c2("rateResetAriaLabel")), E.title = c2("rateResetTitle"), E.textContent = Nn(1);
    const Tt = o.createElement("span");
    Tt.className = "yt-speed-divider", Tt.dataset.role = "divider", Tt.setAttribute("aria-hidden", "true"), Tt.textContent = "|";
    const ft = o.createElement("div");
    ft.className = "yt-quality-group", ft.dataset.role = "quality-group";
    const Dt = o.createElement("div");
    Dt.className = "yt-volume-group", Dt.dataset.role = "volume-group";
    const Yt = o.createElement("div");
    Yt.className = "yt-music-group", Yt.dataset.role = "music-group";
    const qt = o.createElement("div");
    qt.className = "yt-captions-group", qt.dataset.role = "captions-group";
    const Ft = o.createElement("div");
    Ft.className = "yt-pin-group", Ft.dataset.role = "pin-group";
    const Ke = { time: Ot, speed: Vt, volume: Dt, quality: ft, music: Yt, captions: qt, pin: Ft };
    function je() {
      const n2 = c.filter((a) => be[a]).map((a) => Ke[a]).flatMap((a, l) => l === 0 ? [a] : [Tt.cloneNode(true), a]);
      for (const a of c) {
        const l = Ke[a], b2 = be[a];
        l.hidden = !b2, l.dataset.visible = b2 ? "true" : "false";
      }
      xt.replaceChildren(...n2);
    }
    function ze(t) {
      be = y(t), je();
    }
    function Ge(t, n2) {
      if (n2 !== "local") return;
      const a = t[L];
      a && ze(a.newValue);
    }
    function zn() {
      try {
        globalThis.chrome?.storage?.onChanged?.addListener(Ge);
      } catch {
      }
    }
    function Gn() {
      try {
        globalThis.chrome?.storage?.onChanged?.removeListener(Ge);
      } catch {
      }
    }
    function Qe(t, n2, a) {
      const l = (d) => {
        d.preventDefault(), d.stopPropagation(), Qt(n2);
      }, b2 = (d) => {
        d.preventDefault(), d.stopPropagation(), Qt(a);
      };
      t.addEventListener("click", l), t.addEventListener("contextmenu", b2);
    }
    function fe() {
      Ye = Date.now() + 500;
    }
    function Qn(t, n2) {
      const a = Math.min(T, C(n2));
      t.volume !== a && (fe(), t.volume = a);
    }
    function Ut(t) {
      const n2 = C(B ?? t.volume);
      B = _o(Et, t, n2) ? n2 : T, Qn(t, B), vt(t);
    }
    async function He(t) {
      const n2 = f.video ?? y2 ?? U(o);
      if (!n2) {
        x.warn?.("Could not find the active YouTube video.");
        return;
      }
      const a = t > 0 && n2.muted;
      B = Mo(B ?? n2.volume, t), Ut(n2), a && (fe(), n2.muted = false), await Io(Et), vt(n2);
    }
    function Hn() {
      const t = f.video ?? y2 ?? U(o);
      if (!t) {
        x.warn?.("Could not find the active YouTube video.");
        return;
      }
      B = 1, Ut(t), t.muted && (fe(), t.muted = false), vt(t);
    }
    function We(t, n2, a) {
      t.addEventListener("click", (l) => {
        l.preventDefault(), l.stopPropagation(), He(n2);
      }), t.addEventListener("contextmenu", (l) => {
        l.preventDefault(), l.stopPropagation(), He(a);
      });
    }
    function mt(t, n2, a = true) {
      t.addEventListener("click", (l) => {
        l.preventDefault(), l.stopPropagation(), mo(n2);
      }), t.addEventListener("contextmenu", (l) => {
        if (l.preventDefault(), l.stopPropagation(), !!a) {
          if (h2?.button === t) {
            j();
            return;
          }
          go(n2, t);
        }
      });
    }
    Qe(bt, -ne, -hn), mt(X, -Sn, false), mt(J, -xn, false), mt(Z, -Tn, false), Qe(pt, ne, hn), mt(tt, Sn), mt(et, xn), mt(nt, Tn), E.addEventListener("click", (t) => {
      t.preventDefault(), t.stopPropagation(), fo();
    });
    const ot = o.createElement("button");
    ot.type = "button", ot.className = "yt-speed-button", ot.dataset.role = "volume-button", ot.textContent = c2("volumeDecreaseLabel"), ot.title = c2("volumeDecreaseTitle");
    const P = o.createElement("button");
    P.type = "button", P.className = "yt-speed-rate", P.dataset.role = "volume-indicator", P.setAttribute("aria-live", "polite"), P.setAttribute("aria-atomic", "true"), P.textContent = R(1), P.addEventListener("click", (t) => {
      t.preventDefault(), t.stopPropagation(), Hn();
    });
    const rt = o.createElement("button");
    rt.type = "button", rt.className = "yt-speed-button", rt.dataset.role = "volume-button", rt.textContent = c2("volumeIncreaseLabel"), rt.title = c2("volumeIncreaseTitle"), We(ot, -kn, -En), We(rt, kn, En), Dt.append(ot, P, rt);
    const Y = o.createElement("button");
    Y.type = "button", Y.className = "yt-quality-button", Y.dataset.role = "quality-button", Y.dataset.requestedQuality = "auto", Y.setAttribute("aria-pressed", "false"), Y.textContent = c2("qualityAutoLabel"), Y.title = c2("qualityAutoTitle"), Y.addEventListener("click", (t) => {
      t.preventDefault(), t.stopPropagation(), rn();
    }), ft.append(Y);
    for (const t of $o) {
      const n2 = o.createElement("button");
      n2.type = "button", n2.className = "yt-quality-button", n2.dataset.role = "quality-button", n2.dataset.requestedQuality = "resolution", n2.dataset.requestedResolution = String(t), n2.setAttribute("aria-pressed", "false"), n2.textContent = `${t}p`, n2.title = c2("qualityResolutionTitle", [String(t)]), n2.addEventListener("click", (a) => {
        a.preventDefault(), a.stopPropagation(), he(t);
      }), n2.addEventListener("contextmenu", (a) => {
        a.preventDefault(), a.stopPropagation(), de = (de + 1) % Ae.length;
        const l = Ae[de];
        n2.textContent = `${l}p`, n2.dataset.requestedResolution = String(l), n2.title = c2("qualityResolutionTitle", [String(l)]), he(l);
      }), ft.append(n2);
    }
    const T2 = o.createElement("button");
    T2.type = "button", T2.className = "yt-music-button", T2.dataset.role = "music-button", T2.setAttribute("aria-pressed", "false"), T2.setAttribute("aria-label", c2("musicModeEnableAriaLabel")), T2.title = c2("musicModeEnableTitle");
    const q = o.createElementNS("http://www.w3.org/2000/svg", "svg");
    q.setAttribute("viewBox", "0 0 24 24"), q.setAttribute("fill", "none"), q.setAttribute("stroke", "currentColor"), q.setAttribute("stroke-width", "2"), q.setAttribute("stroke-linecap", "round"), q.setAttribute("stroke-linejoin", "round"), q.setAttribute("aria-hidden", "true");
    const Xe = o.createElementNS("http://www.w3.org/2000/svg", "path");
    Xe.setAttribute("d", "M9 18V5l12-2v13");
    const $t = o.createElementNS("http://www.w3.org/2000/svg", "circle");
    $t.setAttribute("cx", "6"), $t.setAttribute("cy", "18"), $t.setAttribute("r", "3");
    const Kt = o.createElementNS("http://www.w3.org/2000/svg", "circle");
    Kt.setAttribute("cx", "18"), Kt.setAttribute("cy", "16"), Kt.setAttribute("r", "3"), q.append(Xe, $t, Kt), T2.append(q), T2.addEventListener("click", (t) => {
      t.preventDefault(), t.stopPropagation(), no(!K);
    }), Yt.append(T2);
    const C2 = o.createElement("button");
    C2.type = "button", C2.className = "yt-captions-button", C2.dataset.role = "captions-button", C2.setAttribute("aria-pressed", "false"), C2.textContent = c2("captionsButtonLabel"), C2.title = c2("captionsEnableTitle"), C2.addEventListener("click", (t) => {
      t.preventDefault(), t.stopPropagation(), on();
    }), qt.append(C2);
    const w = o.createElement("button");
    w.type = "button", w.className = "yt-pin-button", w.dataset.role = "pin-button", w.setAttribute("aria-pressed", "false"), w.setAttribute("aria-label", c2("pinEnableAriaLabel")), w.title = c2("pinEnableTitle");
    const F = o.createElementNS("http://www.w3.org/2000/svg", "svg");
    F.setAttribute("viewBox", "0 0 24 24"), F.setAttribute("fill", "none"), F.setAttribute("stroke", "currentColor"), F.setAttribute("stroke-width", "2"), F.setAttribute("stroke-linecap", "round"), F.setAttribute("stroke-linejoin", "round"), F.setAttribute("aria-hidden", "true");
    const Je = o.createElementNS("http://www.w3.org/2000/svg", "path");
    Je.setAttribute("d", "M12 17v5M5 17h14l-3.5-4V5.5L17 4V2H7v2l1.5 1.5V13L5 17Z"), F.append(Je), w.append(F), w.addEventListener("click", (t) => {
      t.preventDefault(), t.stopPropagation(), ro(!ct);
    }), Ft.append(w), Ot.append(Z, J, X, tt, et, nt), Vt.append(bt, E, pt), je(), zn(), jn().then((t) => {
      m2 || ze(t);
    }), Fn.append(Fe, xt);
    function jt() {
      ut !== null && (r2.clearTimeout(ut), ut = null);
    }
    function Ze() {
      Pt !== null && (r2.clearInterval(Pt), Pt = null);
    }
    function Ct() {
      I?.cleanup(), I = null;
    }
    function me(t) {
      return t.replace(/\s+/g, " ").trim();
    }
    function Wn(t) {
      if (!t) return [];
      const n2 = Array.from(t.querySelectorAll(".ytp-caption-segment")).map((l) => me(l.textContent ?? "")).filter(Boolean);
      if (n2.length > 0) return n2;
      const a = me(t.textContent ?? "");
      return a ? [a] : [];
    }
    function Xn(t) {
      const n2 = t;
      return typeof n2.text == "string" ? n2.text : n2.getCueAsHTML?.()?.textContent ?? "";
    }
    function Jn(t) {
      const n2 = t.textTracks, a = [];
      for (let l = 0; l < n2.length; l += 1) {
        const b2 = n2[l];
        if (!b2 || b2.mode === "disabled" || !["captions", "subtitles"].includes(b2.kind)) continue;
        const d = b2.activeCues;
        if (d) for (let p2 = 0; p2 < d.length; p2 += 1) {
          const O = d[p2];
          if (!O) continue;
          const G = Xn(O).split(/\r?\n/).map(me).filter(Boolean);
          a.push(...G);
        }
      }
      return a;
    }
    function Zn() {
      const t = D;
      t && (t.overlay.replaceChildren(...t.lines.map((n2) => {
        const a = o.createElement("span");
        return a.className = "yt-playback-speed-fast-seek-caption-line", a.textContent = n2, a;
      })), t.overlay.dataset.visible = t.lines.length > 0 ? "true" : "false");
    }
    function ye() {
      const t = D;
      if (!t) return;
      const n2 = Jn(t.video);
      t.nativeCaptionContainer = Pn(t.playerContainer);
      const a = n2.length > 0 ? n2 : Wn(t.nativeCaptionContainer), l = a.map(kt).join(`
`);
      if (!(!l || l === t.lastNormalizedText)) {
        t.lastNormalizedText = l;
        for (const b2 of a) {
          const d = kt(b2);
          if (!(!d || t.lineKeys.has(d))) for (t.lines.push(b2), t.lineKeys.add(d); t.lines.length > Do; ) {
            const p2 = t.lines.shift();
            p2 && t.lineKeys.delete(kt(p2));
          }
        }
        Zn();
      }
    }
    function tn() {
      if (!D) return;
      const t = D;
      D = null, t.observer?.disconnect(), t.playerContainer.classList.remove("yt-playback-speed-fast-seek-captions"), t.overlay.remove();
    }
    function to(t) {
      tn();
      const n2 = f.playerContainer, a = oe(n2);
      if (!n2 || a?.getAttribute("aria-pressed") !== "true") return;
      const l = o.createElement("div");
      l.className = "yt-playback-speed-fast-seek-caption-overlay", l.dataset.role = "fast-seek-caption-overlay", l.dataset.visible = "false", n2.append(l), n2.classList.add("yt-playback-speed-fast-seek-captions"), D = { video: t, playerContainer: n2, nativeCaptionContainer: Pn(n2), overlay: l, lines: [], lineKeys: /* @__PURE__ */ new Set(), lastNormalizedText: "", observer: null };
      const b2 = D.nativeCaptionContainer ?? n2;
      D.observer = new MutationObserver(ye), D.observer.observe(b2, { childList: true, subtree: true, characterData: true }), ye();
    }
    function j(t = true) {
      if (!h2) return;
      const n2 = h2;
      h2 = null, n2.timer !== null && (r2.clearInterval(n2.timer), n2.timer = null), tn(), n2.button && (n2.button.textContent = n2.buttonLabel, n2.button.setAttribute("aria-pressed", "false")), E.setAttribute("aria-pressed", "false"), t && (n2.video.playbackRate = n2.previousPlaybackRate, z(n2.video));
    }
    function eo() {
      T2.setAttribute("aria-pressed", K ? "true" : "false"), T2.setAttribute("aria-label", c2(K ? "musicModeDisableAriaLabel" : "musicModeEnableAriaLabel")), T2.title = c2(K ? "musicModeDisableTitle" : "musicModeEnableTitle");
    }
    function ve() {
      k2?.remove(), k2 = null, W?.classList.remove(ee), W = null, Rt = null;
    }
    function en() {
      if (!K) {
        ve();
        return;
      }
      const t = f.video ?? y2 ?? U(o), n2 = f.playerContainer ?? re(o, t);
      if (!n2) return;
      W && W !== n2 && (W.classList.remove(ee), k2?.remove(), k2 = null), W = n2, W.classList.add(ee), (!k2 || k2.parentElement !== n2) && (k2?.remove(), k2 = o.createElement("div"), k2.className = "yt-playback-speed-music-overlay", k2.dataset.role = "music-overlay", k2.dataset.imageSource = "none", n2.append(k2));
      const l = gt() ?? t?.currentSrc ?? r2.location.href;
      Rt !== l && (Rt = l, k2.style.removeProperty("background-image"), k2.dataset.imageSource = "none", he(Uo));
    }
    function no(t) {
      if (K !== t) {
        if (K = t, eo(), K) {
          Rt = null, en();
          return;
        }
        ve(), rn();
      }
    }
    function oo() {
      w.setAttribute("aria-pressed", ct ? "true" : "false"), w.setAttribute("aria-label", c2(ct ? "pinDisableAriaLabel" : "pinEnableAriaLabel")), w.title = c2(ct ? "pinDisableTitle" : "pinEnableTitle");
    }
    function nn() {
      const t = ct ? f.playerContainer : null;
      $ && $ !== t && $.classList.remove(N), $ = t, $ && $.classList.add(N);
    }
    function ro(t) {
      ct = t, oo(), nn();
    }
    function ao(t, n2) {
      return n2 ? n2.kind === "auto" ? t.dataset.requestedQuality === "auto" : t.dataset.requestedQuality === "resolution" && Number(t.dataset.requestedResolution) === n2.requestedResolution : false;
    }
    function io() {
      const t = ft.querySelectorAll('[data-role="quality-button"]');
      for (const n2 of t) n2.setAttribute("aria-pressed", ao(n2, Oe) ? "true" : "false");
    }
    function yt() {
      const t = oe(f.playerContainer), n2 = t !== null, a = t?.getAttribute("aria-pressed") === "true";
      C2.disabled = !n2, C2.setAttribute("aria-pressed", a ? "true" : "false"), C2.setAttribute("aria-label", c2(a ? "captionsDisableAriaLabel" : "captionsEnableAriaLabel")), C2.title = c2(n2 ? a ? "captionsDisableTitle" : "captionsEnableTitle" : "captionsUnavailableTitle");
    }
    function ge() {
      r2.setTimeout(yt, 0);
    }
    function so() {
      const t = oe(f.playerContainer);
      if (dt === t) {
        yt();
        return;
      }
      dt?.removeEventListener("click", ge), dt = t, dt?.addEventListener("click", ge), yt();
    }
    function on() {
      const t = oe(f.playerContainer);
      if (!t) {
        yt(), x.warn?.("Could not find the YouTube captions button.");
        return;
      }
      t.click(), yt(), r2.setTimeout(yt, 0);
    }
    function lo(t) {
      Oe = t.kind === "auto" ? { kind: "auto" } : { kind: "resolution", requestedResolution: t.requestedResolution }, io();
    }
    function zt() {
      m2 || R2 === null || ut !== null || (ut = r2.setTimeout(() => {
        ut = null, Gt();
      }, Fo));
    }
    function rn() {
      R2 = { kind: "auto" }, _ += 1, jt(), Gt(_);
    }
    function he(t) {
      R2 = { kind: "resolution", requestedResolution: t }, _ += 1, jt(), Gt(_);
    }
    async function Gt(t = _) {
      if (!(m2 || le || R2 === null) && t === _) {
        le = true;
        try {
          const n2 = R2, a = f.playerContainer ?? re(o, f.video ?? U(o));
          if (a) f.playerContainer = a;
          else {
            zt();
            return;
          }
          const l = await Cr(r2, a);
          if (m2 || t !== _ || R2 !== n2) return;
          if (!l) {
            zt();
            return;
          }
          const b2 = yr(l), d = n2.kind === "auto" ? On(b2) : lr(n2.requestedResolution, b2);
          if (!d || n2.kind === "resolution" && d.resolution === null) {
            zt();
            return;
          }
          d.element.click(), t === _ && R2 === n2 && (lo(n2), R2 = null, jt());
        } catch (n2) {
          x.warn?.(n2 instanceof Error ? n2.message : "Could not change the resolution."), zt();
        } finally {
          le = false, !m2 && R2 !== null && t !== _ && queueMicrotask(() => {
            Gt(_);
          });
        }
      }
    }
    function z(t = y2 ?? f.video) {
      E.textContent = Nn(t?.playbackRate);
    }
    function ke() {
      z(y2 ?? f.video);
    }
    function vt(t = y2 ?? f.video) {
      const n2 = B ?? t?.volume ?? 1, a = t?.muted ?? false, l = !a && n2 > 1 ? Math.min(10, Math.max(1, Math.round((n2 - 1) * 10))) : 0;
      P.textContent = R(n2, a), P.dataset.volumeBoosted = l > 0 ? "true" : "false", P.dataset.volumeBoostLevel = String(l);
    }
    function Ee() {
      const t = y2 ?? f.video;
      if (!t) return;
      const n2 = Math.min(T, B ?? t.volume);
      if (Date.now() < Ye && t.volume === n2) {
        vt(t);
        return;
      }
      B = C(t.muted ? 0 : t.volume), Nt(Et), vt(t);
    }
    function at() {
      _t !== null && (r2.clearInterval(_t), _t = null), ue = null, ce = 0;
    }
    function an() {
      const t = ue;
      if (!t || Date.now() > ce) {
        at();
        return;
      }
      t.playbackRate !== 1 && (t.playbackRate = 1), z(t);
    }
    function uo(t) {
      at(), ue = t, ce = Date.now() + Yo, an(), _t = r2.setInterval(an, qo);
    }
    function gt() {
      return Ie(r2.location.href);
    }
    function sn(t, n2) {
      if (gt() !== t) return;
      const a = `${r2.location.pathname}${r2.location.search}${r2.location.hash}`;
      n2 !== a && Wt(r2.history.state, "", n2);
    }
    function A(t = g2, n2 = H) {
      if (!t || !n2) return;
      const a = t.currentTime, l = I ? In(I.entry) : null;
      if (Date.now() < Ve && I?.video === t && I.videoId === n2 && l !== null && (!Number.isFinite(a) || a < l - At)) return;
      const b2 = Sr(t), d = xr(t);
      if (!b2 && !d) return;
      const p2 = b2 ? ae(r2.location.href, n2, a) : null;
      if (!St) {
        p2 && sn(n2, p2);
        return;
      }
      Rn(St, x).then((O) => {
        d ? delete O[n2] : p2 && (sn(n2, p2), O[n2] = { url: p2, time: a, duration: lt(t), updatedAt: Date.now() }), Er(St, O, x);
      });
    }
    function ln(t, n2, a) {
      Ct();
      const l = ["loadedmetadata", "durationchange", "canplay", "play", "playing", "timeupdate"], b2 = Date.now() + Qo, d = In(a);
      Ve = b2 + 1e3;
      const p2 = { video: t, videoId: n2, entry: a, deadlineAt: b2, stableSince: null, reachedPosition: false, timer: null, cleanup() {
        p2.timer !== null && (r2.clearInterval(p2.timer), p2.timer = null);
        for (const Zt of l) t.removeEventListener(Zt, G);
        I === p2 && (I = null);
      } }, O = () => !m2 && g2 === t && H === n2 && I === p2;
      function G() {
        if (!O()) {
          p2.cleanup();
          return;
        }
        if (Date.now() > p2.deadlineAt || !Pe(a, t)) {
          p2.cleanup();
          return;
        }
        if (Math.abs(t.currentTime - d) <= At) {
          p2.reachedPosition = true, p2.stableSince ?? (p2.stableSince = Date.now()), Date.now() - p2.stableSince >= Ho && p2.cleanup();
          return;
        }
        if (p2.reachedPosition && t.currentTime > d + At) {
          p2.cleanup();
          return;
        }
        p2.stableSince = null;
        try {
          t.currentTime = d, p2.reachedPosition = true;
        } catch {
        }
      }
      I = p2;
      for (const Zt of l) t.addEventListener(Zt, G);
      p2.timer = r2.setInterval(G, Go), G();
    }
    function co(t, n2) {
      const a = dr(r2.location.href);
      if (a !== null) {
        const l = { url: ae(r2.location.href, n2, a), time: a, duration: lt(t), updatedAt: Date.now() };
        Pe(l, t) && ln(t, n2, l);
        return;
      }
      St && Rn(St, x).then((l) => {
        const b2 = l[n2];
        if (m2 || g2 !== t || H !== n2 || !b2 || !Pe(b2, t)) return;
        const d = `${r2.location.pathname}${r2.location.search}${r2.location.hash}`;
        b2.url !== d && Wt(r2.history.state, "", b2.url), ln(t, n2, b2);
      });
    }
    function M() {
      A();
    }
    function bo(t, n2) {
      g2 === t && H === n2 || (A(), Ct(), g2 && (g2.removeEventListener("pause", M), g2.removeEventListener("ended", M), g2.removeEventListener("seeked", M)), Ze(), g2 = t, H = n2, !(!g2 || !H) && (uo(g2), g2.addEventListener("pause", M), g2.addEventListener("ended", M), g2.addEventListener("seeked", M), Pt = r2.setInterval(M, Ko), co(g2, H)));
    }
    function po(t) {
      if (y2 === t) {
        z(t), t && Ut(t);
        return;
      }
      y2 && (j(), Nt(Et), y2.removeEventListener("ratechange", ke), y2.removeEventListener("volumechange", Ee)), y2 = t, y2 && (B ?? (B = C(y2.volume)), y2.addEventListener("ratechange", ke), y2.addEventListener("volumechange", Ee), Ut(y2)), z(t), vt(t);
    }
    function Qt(t) {
      const n2 = f.video ?? y2 ?? U(o);
      if (!n2) {
        x.warn?.("Could not find the active YouTube video.");
        return;
      }
      j(), at(), n2.playbackRate = ur(n2.playbackRate, t), z(n2);
    }
    function fo() {
      const t = f.video ?? y2 ?? U(o);
      if (!t) {
        x.warn?.("Could not find the active YouTube video.");
        return;
      }
      j(), at(), t.playbackRate = 1, z(t);
    }
    function un(t) {
      if (t.defaultPrevented || t.ctrlKey || t.altKey || t.metaKey || Tr(t.target)) return;
      const n2 = t.key.toLowerCase();
      n2 === "x" ? (t.preventDefault(), Qt(-ne)) : n2 === "c" ? (t.preventDefault(), Qt(ne)) : n2 === "z" && (t.preventDefault(), t.stopPropagation(), on());
    }
    function mo(t) {
      const n2 = f.video ?? y2 ?? U(o);
      if (!n2) {
        x.warn?.("Could not find the active YouTube video.");
        return;
      }
      j(), at(), Ct();
      const l = lt(n2) ?? Number.POSITIVE_INFINITY;
      n2.currentTime = Math.min(l, Math.max(0, n2.currentTime + t)), A(n2, gt());
    }
    function yo(t, n2) {
      const a = Math.max(0, Math.ceil(n2));
      return t < 0 ? `\u2190${a}s` : `${a}s\u2192`;
    }
    function Se(t) {
      const n2 = h2;
      if (!n2 || n2.video !== t) return;
      const a = Math.abs(n2.targetTime - t.currentTime);
      n2.button && (n2.button.textContent = yo(n2.deltaSeconds, a)), ye();
    }
    function cn(t, n2) {
      const a = h2;
      if (!a || a.video !== t) return;
      const l = a.wasPaused;
      t.currentTime = n2, j(), l ? t.pause() : t.play?.(), A(t, gt());
    }
    function vo(t, n2, a, l, b2, d) {
      h2 = { video: t, targetTime: n2, button: l, buttonLabel: l?.textContent ?? "", deltaSeconds: a, previousPlaybackRate: b2, wasPaused: d, timer: null }, l?.setAttribute("aria-pressed", "true"), E.setAttribute("aria-pressed", "true"), Se(t), to(t);
    }
    function go(t, n2 = null) {
      const a = f.video ?? y2 ?? U(o);
      if (!a) {
        x.warn?.("Could not find the active YouTube video.");
        return;
      }
      j(), at(), Ct();
      const b2 = lt(a) ?? Number.POSITIVE_INFINITY, d = Math.min(b2, Math.max(0, a.currentTime + t));
      if (Math.abs(d - a.currentTime) <= At) {
        a.currentTime = d, A(a, gt());
        return;
      }
      const p2 = a.playbackRate, O = a.paused;
      if (vo(a, d, t, n2, p2, O), t > 0) {
        a.playbackRate = Cn, z(a), a.play?.(), h2 && (h2.timer = r2.setInterval(() => {
          if (!h2 || h2.video !== a || a.currentTime >= d || a.ended) {
            cn(a, d);
            return;
          }
          Se(a);
        }, we));
        return;
      }
      a.pause(), h2 && (h2.timer = r2.setInterval(() => {
        if (!h2 || h2.video !== a) return;
        const G = Cn * we / 1e3;
        a.currentTime = Math.max(d, a.currentTime - G), Se(a), a.currentTime <= d + At && cn(a, d);
      }, we));
    }
    function ho() {
      const { playerContainer: t } = f;
      t && (Yn(t), qe(), S.parentElement !== t && (S.remove(), t.append(S)));
    }
    function it() {
      if (m2) return;
      const t = U(o), n2 = re(o, t), a = br(o, t), l = gt();
      if (f = { video: t, controlsRoot: a, playerContainer: n2 }, nn(), so(), po(t), bo(t, l), en(), !n2) {
        S.remove();
        return;
      }
      ho();
    }
    function Ht() {
      m2 || V || (V = true, queueMicrotask(() => {
        V = false, it();
      }));
    }
    function dn() {
      m2 || (it(), !f.playerContainer && De < Jo && (De += 1, It = r2.setTimeout(dn, Xo)));
    }
    function ko() {
      It !== null && (r2.clearTimeout(It), It = null);
    }
    function bn() {
      Bt !== null && (r2.clearInterval(Bt), Bt = null);
    }
    const pn = r2.history.pushState.bind(r2.history), Wt = r2.history.replaceState.bind(r2.history);
    r2.history.pushState = ((...t) => {
      A();
      const n2 = pn(...t);
      return Ht(), n2;
    }), r2.history.replaceState = ((...t) => {
      A();
      const n2 = Wt(...t);
      return Ht(), n2;
    });
    const Xt = () => {
      A(), Ht();
    };
    function fn(t) {
      return t === S || t === k2 ? true : t instanceof Element ? t.matches(`[${ht}], .yt-playback-speed-music-overlay`) || t.closest(`[${ht}], .yt-playback-speed-music-overlay`) !== null : t.parentElement ? fn(t.parentElement) : false;
    }
    function Eo(t) {
      if (t.type !== "childList") return false;
      const n2 = [...Array.from(t.addedNodes), ...Array.from(t.removedNodes)];
      return n2.length > 0 && n2.every(fn);
    }
    const So = (t) => {
      t.length > 0 && t.every(Eo) || Ht();
    }, Jt = () => {
      A();
    }, mn = () => {
      o.visibilityState === "hidden" && A();
    }, L2 = () => {
      A(), r2.setTimeout(() => {
        m2 || it();
      }, er);
    };
    r2.addEventListener("popstate", Xt), r2.addEventListener("hashchange", Xt), r2.addEventListener("pagehide", Jt), r2.addEventListener("beforeunload", Jt), o.addEventListener("visibilitychange", mn), o.addEventListener("keydown", un, true), o.addEventListener("yt-navigate-finish", L2), r2.addEventListener("yt-navigate-finish", L2), o.addEventListener("yt-navigate", L2), r2.addEventListener("yt-navigate", L2), o.addEventListener("yt-player-updated", L2), r2.addEventListener("yt-player-updated", L2), se = new MutationObserver(So), se.observe(o.documentElement, { childList: true, subtree: true }), dn(), o.readyState !== "complete" && r2.addEventListener("load", () => {
      !m2 && (!f.playerContainer || !S.isConnected) && it();
    }, { once: true });
    const xo = Date.now();
    Bt = r2.setInterval(() => {
      if (m2 || Date.now() - xo > tr) {
        bn();
        return;
      }
      (!f.playerContainer || !S.isConnected) && it();
    }, Zo), r2.setTimeout(() => {
      !m2 && (!f.playerContainer || !S.isConnected) && it();
    }, 1e4), r2.setTimeout(() => {
      !m2 && (!f.playerContainer || !S.isConnected) && it();
    }, 45e3);
    const xe = { destroy() {
      m2 || (m2 = true, A(), jt(), Ze(), Ct(), j(), at(), ve(), Nt(Et), R2 = null, $?.classList.remove(N), $ = null, dt?.removeEventListener("click", ge), dt = null, y2 && (y2.removeEventListener("ratechange", ke), y2.removeEventListener("volumechange", Ee)), g2 && (g2.removeEventListener("pause", M), g2.removeEventListener("ended", M), g2.removeEventListener("seeked", M)), Kn(), Gn(), se?.disconnect(), ko(), bn(), r2.removeEventListener("popstate", Xt), r2.removeEventListener("hashchange", Xt), r2.removeEventListener("pagehide", Jt), r2.removeEventListener("beforeunload", Jt), o.removeEventListener("visibilitychange", mn), o.removeEventListener("keydown", un, true), o.removeEventListener("yt-navigate-finish", L2), r2.removeEventListener("yt-navigate-finish", L2), o.removeEventListener("yt-navigate", L2), r2.removeEventListener("yt-navigate", L2), o.removeEventListener("yt-player-updated", L2), r2.removeEventListener("yt-player-updated", L2), r2.history.pushState = pn, r2.history.replaceState = Wt, Mt.remove(), S.remove(), u[te] === xe && delete u[te]);
    } };
    return u[te] = xe, xe;
  }
  try {
    wr();
  } catch (e) {
    console.error("[Playback Controls for YouTube] Failed to initialize:", e);
  }
})();
